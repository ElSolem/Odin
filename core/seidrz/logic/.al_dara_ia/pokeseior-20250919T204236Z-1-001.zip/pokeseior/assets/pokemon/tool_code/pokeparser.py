# Adjusted move parser with safe int conversion
def safe_extract_moves(tag, paired=False):
    pattern = rf"{tag}\s*=\s*(.+)"
    match = re.search(pattern, entry)
    if not match:
        return [] if not paired else []
    values = [v.strip() for v in match.group(1).split(",")]

    if paired:
        parsed = []
        i = 0
        while i < len(values) - 1:
            try:
                level = int(values[i])
                move = values[i + 1]
                parsed.append({"level": level, "move": move})
                i += 2
            except ValueError:
                # Fallback: ignore or store malformed entries if needed
                i += 1  # Skip the problematic value
        return parsed
    else:
        return values

# Reparse with safe function
parsed_pokemon = []
for entry in entries:
    if not entry.strip():
        continue

    name_match = re.search(r"\[(.+?)\]", entry)
    if not name_match:
        continue
    name = name_match.group(1)

    moves = safe_extract_moves("Moves", paired=True)
    tutor_moves = safe_extract_moves("TutorMoves")
    egg_moves = safe_extract_moves("EggMoves")

    evolutions = []
    evo_match = re.search(r"Evolutions\s*=\s*(.+)", entry)
    if evo_match:
        evolutions = [v.strip() for v in evo_match.group(1).split(",")]

    habitat = None
    habitat_match = re.search(r"Habitat\s*=\s*(.+)", entry)
    if habitat_match:
        habitat = habitat_match.group(1).strip()

    parsed_pokemon.append({
        "name": name,
        "moves": moves,
        "tutor_moves": tutor_moves,
        "egg_moves": egg_moves,
        "evolutions": evolutions if evolutions else None,
        "habitat": habitat
    })

# Save to JSON again
output_path = "/mnt/data/pokemon_clean.json"
with open(output_path, "w", encoding="utf-8") as out_file:
    json.dump(parsed_pokemon, out_file, indent=2)

output_path
