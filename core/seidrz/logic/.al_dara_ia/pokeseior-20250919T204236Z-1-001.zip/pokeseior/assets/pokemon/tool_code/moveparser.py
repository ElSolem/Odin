import re
import json
from pathlib import Path

# Set your input and output paths here
input_path = Path("/home/elsolem/Documents/pokeseior/assets/pokemon/tool_code/moves.txt")
output_path = Path("/home/elsolem/Documents/pokeseior/assets/pokemon/data/moves.json")

# Read the file
with open(input_path, "r", encoding="utf-8") as f:
    raw_data = f.read()

# Split into blocks by # separator
entries = re.split(r"#-+\n", raw_data)
parsed_moves = []

for entry in entries:
    if not entry.strip():
        continue

    def extract(key, is_int=False):
        match = re.search(rf"{key}\s*=\s*(.+)", entry)
        if match:
            val = match.group(1).strip()
            return int(val) if is_int and val.isdigit() else val
        return None

    id_match = re.search(r"\[(.+?)\]", entry)
    if not id_match:
        continue

    move = {
        "id": id_match.group(1),
        "name": extract("Name"),
        "type": extract("Type"),
        "category": extract("Category"),
        "power": extract("Power", is_int=True),
        "accuracy": extract("Accuracy", is_int=True),
        "pp": extract("TotalPP", is_int=True),
        "target": extract("Target"),
        "function_code": extract("FunctionCode"),
        "flags": [flag.strip() for flag in extract("Flags").split(",")] if extract("Flags") else [],
        "effect_chance": extract("EffectChance", is_int=True),
        "description": extract("Description")
    }

    parsed_moves.append(move)

# Save to JSON
with open(output_path, "w", encoding="utf-8") as out_file:
    json.dump(parsed_moves, out_file, indent=2)

print(f"Parsed {len(parsed_moves)} moves → saved to {output_path}")
