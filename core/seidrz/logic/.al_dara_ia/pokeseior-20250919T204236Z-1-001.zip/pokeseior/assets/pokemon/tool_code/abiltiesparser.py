import re
import json

# Load the abilities file
abilities_path = "/home/elsolem/Documents/pokeseior/assets/tool_code/abilities.txt"
with open(abilities_path, "r", encoding="utf-8") as f:
    raw_abilities = f.read()

# Split into entries
entries = re.split(r"#-+\n", raw_abilities)
parsed_abilities = []

# Parse each ability block
for entry in entries:
    if not entry.strip():
        continue

    name_match = re.search(r"\[(.+?)\]", entry)
    description_match = re.search(r"Description\s*=\s*(.+)", entry)

    if name_match and description_match:
        name = name_match.group(1).strip()
        description = description_match.group(1).strip()
        parsed_abilities.append({
            "name": name,
            "description": description
        })

# Save to JSON
abilities_json_path = "/home/elsolem/Documents/pokeseior/assets/data/abilities.json"
with open(abilities_json_path, "w", encoding="utf-8") as out_file:
    json.dump(parsed_abilities, out_file, indent=2)

abilities_json_path
