import re
import json

# Load the items file
items_path = "/home/elsolem/Documents/pokeseior/assets/pokemon/tool_code/items_Gen_9_Pack.txt"
with open(items_path, "r", encoding="utf-8") as f:
    raw_items = f.read()

# Split entries by # separator
entries = re.split(r"#-+\n", raw_items)
parsed_items = []

# Parse each item block
for entry in entries:
    if not entry.strip():
        continue

    name_match = re.search(r"\[(.+?)\]", entry)
    price_match = re.search(r"Price\s*=\s*(\d+)", entry)
    sell_price_match = re.search(r"SellPrice\s*=\s*(\d+)", entry)
    flags_match = re.search(r"Flags\s*=\s*(.+)", entry)

    if name_match:
        item_data = {
            "name": name_match.group(1).strip(),
            "price": int(price_match.group(1)) if price_match else None,
            "sell_price": int(sell_price_match.group(1)) if sell_price_match else None,
            "flags": flags_match.group(1).strip() if flags_match else None
        }
        parsed_items.append(item_data)

# Save to JSON
items_json_path = "/home/elsolem/Documents/pokeseior/assets/pokemon/data/items3.json"
with open(items_json_path, "w", encoding="utf-8") as out_file:
    json.dump(parsed_items, out_file, indent=2)

items_json_path
